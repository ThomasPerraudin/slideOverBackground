slideOverBackground
===================

A simple responsive background slideshow plugin for jQuery

[Click here for Demonstration and Download](http://thomas.perraudin.fr/softwares/slideOverBackground/sample/ "Demonstration")
